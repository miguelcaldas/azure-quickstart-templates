# Description

**Type:** Distributed
**Requires CredSSP:** No

This resource is responsible for managing the search crawl rules in the search
service application. You can create new rules, change existing rules and remove
existing rules.

The default value for the Ensure parameter is Present. When not specifying this
parameter, the crawl rule is created.
